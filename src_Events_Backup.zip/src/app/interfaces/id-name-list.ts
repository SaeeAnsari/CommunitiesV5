export interface ID_Name_Pair {
    id:number;
    name:string;
  
}
