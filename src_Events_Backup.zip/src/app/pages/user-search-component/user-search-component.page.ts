import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-search-component',
  templateUrl: './user-search-component.page.html',
  styleUrls: ['./user-search-component.page.scss'],
})
export class UserSearchComponentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
