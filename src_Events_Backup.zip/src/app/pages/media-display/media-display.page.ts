import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-display',
  templateUrl: './media-display.page.html',
  styleUrls: ['./media-display.page.scss'],
})
export class MediaDisplayPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
