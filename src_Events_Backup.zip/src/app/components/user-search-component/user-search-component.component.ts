import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-search-component',
  templateUrl: './user-search-component.component.html',
  styleUrls: ['./user-search-component.component.scss'],
})
export class UserSearchComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
